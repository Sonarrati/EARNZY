<?php

namespace Ezoic_Namespace;


/**
 * Class Ezoic_AdsTxtManager_Empty_Solution
 * @package Ezoic_Namespace
 */
class Ezoic_AdsTxtManager_Empty_Solution implements iAdsTxtManager_Solution {
    public function SetupSolution(){ return; }
    public function TearDownSolution(){ return; }
}
