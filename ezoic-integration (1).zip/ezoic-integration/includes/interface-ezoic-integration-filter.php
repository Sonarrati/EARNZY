<?php
namespace Ezoic_Namespace;

interface iEzoic_Integration_Filter {
    public function we_should_return_orig();
}
