<?php

require_once( dirname( __FILE__ ) . '/class-ezoic-adpos-widget.php' );
require_once( dirname( __FILE__ ) . '/class-ezoic-adpos.php' );