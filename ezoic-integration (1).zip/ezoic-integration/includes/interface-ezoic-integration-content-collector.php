<?php
namespace Ezoic_Namespace;

interface iEzoic_Integration_Content_Collector {
    public function get_orig_content();
}
